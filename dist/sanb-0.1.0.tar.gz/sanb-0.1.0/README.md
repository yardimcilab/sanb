sanb (Self-Aware NoteBooks) allows tagging jupyter notebook cells with unique identifiers and identifying their index in the notebook.
